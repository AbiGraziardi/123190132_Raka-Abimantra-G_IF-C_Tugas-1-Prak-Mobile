package com.example.tugas1_123190132_raka

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
